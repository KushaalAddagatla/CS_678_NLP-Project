import os 
import json 
import re 
import random 
from collections import defaultdict 
import argparse 

from torch.utils.data import DataLoader, Dataset


import transformers 
from transformers import BartTokenizer
import torch 
from torch.utils.data import DataLoader 
import pytorch_lightning as pl 

import spacy 
from spacy.tokens import Doc

from sentence_transformers import SentenceTransformer, util

MAX_CONTEXT_LENGTH=400  
MAX_LENGTH=512
MAX_TGT_LENGTH=70

PRONOUN_FILE='../pronoun_list.txt'
pronoun_set = set() 
with open(PRONOUN_FILE, 'r') as f:
    for line in f:
        pronoun_set.add(line.strip())


def check_pronoun(text):
    if text.lower() in pronoun_set:
        return True 
    else:
        return False 


def clean_mention(text):
    prefixes = ['the ', 'The ', 'an ', 'An ', 'a ', 'A ']
    for prefix in prefixes:
        if text.startswith(prefix):
            return text[len(prefix):]
    return text 


def load_ontology(dataset, ontology_file=None):
    ontology_dict ={} 
    if not ontology_file: 
        if not dataset:
            raise ValueError
        with open('../event_role_{}.json'.format(dataset),'r') as f:
            ontology_dict = json.load(f)
    else:
        with open(ontology_file,'r') as f:
            ontology_dict = json.load(f)

    for evt_name, evt_dict in ontology_dict.items():
        for i, argname in enumerate(evt_dict['roles']):
            evt_dict['arg{}'.format(i+1)] = argname
            if argname in evt_dict:
                evt_dict[argname].append('arg{}'.format(i+1))
            else:
                evt_dict[argname] = ['arg{}'.format(i+1)]

    for evt_name, evt_dict in ontology_dict.items():
        evt_dict['arg_to_prev'] = {}
        for i, argname in enumerate(evt_dict['roles']):
            template_words = evt_dict['template'].strip().split()
            try:
                idx = template_words.index("<" + evt_dict[argname][0] + ">")
            except ValueError:
                idx = 0
            if idx == 0:
                evt_dict['arg_to_prev'][argname] = "<s>"
            else:
                evt_dict['arg_to_prev'][argname] = template_words[idx-1]

    
    return ontology_dict


def my_collate(batch):
    doc_keys = [ex['doc_key'] for ex in batch]
    event_type = [ex['event_type'] for ex in batch]
    input_token_ids = torch.stack([torch.LongTensor(ex['input_token_ids']) for ex in batch]) 
    input_attn_mask = torch.stack([torch.BoolTensor(ex['input_attn_mask']) for ex in batch])
    tgt_token_ids = torch.stack([torch.LongTensor(ex['tgt_token_ids']) for ex in batch]) 
    tgt_attn_mask = torch.stack([torch.BoolTensor(ex['tgt_attn_mask']) for ex in batch])

    input_template = [ex['input_template'] for ex in batch]
    context_tokens = [ex['context_tokens'] for ex in batch]
    context_words = [ex['context_words'] for ex in batch]

    return {
        'input_token_ids': input_token_ids,
        'event_type': event_type,
        'input_attn_mask': input_attn_mask,
        'tgt_token_ids': tgt_token_ids,
        'tgt_attn_mask': tgt_attn_mask,
        'doc_key': doc_keys,
        'input_template': input_template,
        'context_tokens': context_tokens,
        'context_words': context_words,
    }


class IEDataset(Dataset):
    def __init__(self, input_file):
        super().__init__()
        self.examples = []
        with open(input_file, 'r') as f:
            for line in f:
                ex = json.loads(line.strip())
                self.examples.append(ex)
    
    def __len__(self):
        return len(self.examples)
    
    def __getitem__(self, idx):
        return self.examples[idx]




class KAIROSDataModule(pl.LightningDataModule):
    def __init__(self, args):
        super().__init__() 
        self.hparams = args 
        
        # self.hparams.update(vars(args))

        self.tokenizer = BartTokenizer.from_pretrained('facebook/bart-large')
        self.tokenizer.add_tokens([' <arg>',' <tgr>'])

        self.sim_model = SentenceTransformer('paraphrase-MiniLM-L6-v2')
    

    def create_gold_gen(self, ex, ontology_dict,mark_trigger=True, index=0, ent2info=None, use_info=False):
        if use_info and ent2info==None:
            raise ValueError('entity to informative mention mapping required.')

        evt_type = ex['event_mentions'][index]['event_type']

        
        template = ontology_dict[evt_type]['template']
        input_template = re.sub(r'<arg\d>', '<arg>', template) 


        space_tokenized_input_template = input_template.split()
        tokenized_input_template = [] 
        for w in space_tokenized_input_template:
            tokenized_input_template.extend(self.tokenizer.tokenize(w, add_prefix_space=True))
        
        role2arg = defaultdict(list)

        for argument in ex['event_mentions'][index]['arguments']:
            role2arg[argument['role']].append(argument)

        role2arg = dict(role2arg)

        arg_idx2text = defaultdict(list)
        for role in role2arg.keys():
            if role not in ontology_dict[evt_type]:
                continue 
            for i, argument in enumerate(role2arg[role]):
                use_arg = True 
                if use_info:
                    ent_id = argument['entity_id']
                    if ent_id in ent2info:
                        arg_text = clean_mention(ent2info[ent_id])
                        if check_pronoun(arg_text):
                            use_arg = False 
                    else:
                        arg_text = argument['text']
                else:
                    arg_text = argument['text']
                
                if i < len(ontology_dict[evt_type][role]):
                    arg_idx = ontology_dict[evt_type][role][i]
                    
                else:
                    arg_idx = ontology_dict[evt_type][role][-1]

                if use_arg:
                    arg_idx2text[arg_idx].append(arg_text)
                
        for arg_idx, text_list in arg_idx2text.items():
            text = ' and '.join(text_list)
            template = re.sub('<{}>'.format(arg_idx), text, template)

            

        trigger = ex['event_mentions'][index]['trigger']
        offset = 0 
        context_words = ex['tokens']
        center_sent = trigger['sent_idx']
        if len(context_words) > MAX_CONTEXT_LENGTH:
            cur_len = len(ex['sentences'][center_sent][0])
            context_words = [tup[0] for tup in ex['sentences'][center_sent][0]]
            if cur_len > MAX_CONTEXT_LENGTH:
                trigger_start = trigger['start']
                start_idx = max(0, trigger_start- MAX_CONTEXT_LENGTH//2 )
                end_idx = min(len(context_words), trigger_start + MAX_CONTEXT_LENGTH //2  )
                context_words = context_words[start_idx: end_idx]
                offset = start_idx 

            else:
                left = center_sent -1 
                right = center_sent +1 
                
                total_sents = len(ex['sentences'])
                prev_len =0 
                while cur_len >  prev_len:
                    prev_len = cur_len 
                    if left >= 0:
                        left_sent_tokens = [tup[0] for tup in ex['sentences'][left][0]]
                        if cur_len + len(left_sent_tokens) <= MAX_CONTEXT_LENGTH:
                            context_words = left_sent_tokens + context_words
                            left -=1 
                            cur_len += len(left_sent_tokens)
                    
                    if right < total_sents:
                        right_sent_tokens = [tup[0] for tup in ex['sentences'][right][0]]
                        if cur_len + len(right_sent_tokens) <= MAX_CONTEXT_LENGTH:
                            context_words = context_words + right_sent_tokens
                            right +=1 
                            cur_len += len(right_sent_tokens)
                offset = sum([len(ex['sentences'][idx][0]) for idx in range(left+1)])
        
            
        assert(len(context_words) <= MAX_CONTEXT_LENGTH) 

        trigger['start'] = trigger['start'] - offset 
        trigger['end'] = trigger['end'] - offset 
        if mark_trigger:
            prefix = self.tokenizer.tokenize(' '.join(context_words[:trigger['start']]), add_prefix_space=True) 
            tgt = self.tokenizer.tokenize(' '.join(context_words[trigger['start']: trigger['end']]), add_prefix_space=True)
            
            suffix = self.tokenizer.tokenize(' '.join(context_words[trigger['end']:]), add_prefix_space=True)
            context = prefix + [' <tgr>', ] + tgt + [' <tgr>', ] + suffix 
        else:
            context = self.tokenizer.tokenize(' '.join(context_words), add_prefix_space=True)

        output_template = re.sub(r'<arg\d>','<arg>', template ) 
        space_tokenized_template = output_template.split()
        tokenized_template = [] 
        for w in space_tokenized_template:
            tokenized_template.extend(self.tokenizer.tokenize(w, add_prefix_space=True))
        
        context_emb = self.sim_model.encode(' '.join(context_words), show_progress_bar=False)
        out_template_emb = self.sim_model.encode(output_template, show_progress_bar=False)
        return tokenized_input_template, tokenized_template, context, context_emb, out_template_emb, ' '.join(context_words)

    


            
    def prepare_data(self):
        if self.hparams.sim_train:
            if not self.hparams.adv:
                data_dir = 'preprocessed_simtr_{}'.format(self.hparams.dataset)
            else:
                data_dir = 'preprocessed_simtr_adv_{}'.format(self.hparams.dataset)
        else:
            data_dir = 'preprocessed_{}'.format(self.hparams.dataset)
        if not os.path.exists(data_dir):
            os.makedirs(data_dir)
            ontology_dict = load_ontology(self.hparams.dataset) 
            max_tokens = 0
            max_tgt =0 

            

            for split,f in [('train',self.hparams.train_file), ('val',self.hparams.val_file), ('test',self.hparams.test_file)]:
                coref_split = 'dev' if split=='val' else split 
                if self.hparams.adv and split == 'test':
                    coref_reader = open(os.path.join(self.hparams.coref_dir, '{}_adv.jsonlines'.format(coref_split)))
                else:
                    coref_reader = open(os.path.join(self.hparams.coref_dir, '{}.jsonlines'.format(coref_split)))
                with open(f,'r') as reader,  open(os.path.join(data_dir,'{}.jsonl'.format(split)), 'w') as writer:
                    for line, coref_line in zip(reader, coref_reader):
                        ex = json.loads(line.strip())
                        corefs = json.loads(coref_line.strip())
                        if ex['doc_id'] != corefs['doc_key']: print(split, ex['doc_id'], corefs['doc_key'])
                        assert(ex['doc_id'] == corefs['doc_key'])
                        ent2info = {} 
                        for cidx, cluster in enumerate(corefs['clusters']):
                            for eid in cluster:
                                ent2info[eid] = corefs['informative_mentions'][cidx]
                            
                        all_output_templates, all_out_template_embs = [], []
                        for i in range(len(ex['event_mentions'])):
                            if split=='train' and len(ex['event_mentions'][i]['arguments']) ==0:
                                continue 
                            evt_type = ex['event_mentions'][i]['event_type']

                            if evt_type not in ontology_dict:
                                continue 
                            
                            input_template, output_template, context, context_emb, out_template_emb, context_words = self.create_gold_gen(ex, ontology_dict, self.hparams.mark_trigger, 
                                index=i, ent2info=ent2info, use_info=self.hparams.use_info)

                            most_sim_out_template = []
                            if len(all_out_template_embs)>0:
                                cosine_scores = util.pytorch_cos_sim([context_emb], all_out_template_embs)
                                most_sim_idx = torch.argmax(cosine_scores, dim=-1)
                                most_sim_out_template = all_output_templates[most_sim_idx]
                            all_output_templates.append(output_template)
                            all_out_template_embs.append(out_template_emb)

                            max_tokens = max(len(context) + len(input_template) +2, max_tokens)
                            max_tgt = max(len(output_template) +1 , max_tgt)
                            assert(len(output_template) < MAX_TGT_LENGTH)

                            if (split == 'train' or split == 'val') and self.hparams.sim_train:
                                context = most_sim_out_template+['</s>']+context
                            input_tokens = self.tokenizer.encode_plus(input_template, context,
                                    add_special_tokens=True,
                                    add_prefix_space=True,
                                    max_length=MAX_LENGTH,
                                    truncation='only_second',
                                    padding='max_length')
                            tgt_tokens = self.tokenizer.encode_plus(output_template, 
                            add_special_tokens=True,
                            add_prefix_space=True, 
                            max_length=MAX_TGT_LENGTH,
                            truncation=True,
                            padding='max_length')

                            processed_ex = {
                                'event_idx': i, 
                                'doc_key': ex['doc_id'], 
                                'event_type': evt_type, 
                                'input_token_ids':input_tokens['input_ids'],
                                'input_attn_mask': input_tokens['attention_mask'],
                                'tgt_token_ids': tgt_tokens['input_ids'],
                                'tgt_attn_mask': tgt_tokens['attention_mask'],
                                'input_template': input_template,
                                'context_tokens': context,
                                'context_words': context_words,
                            }
                            writer.write(json.dumps(processed_ex) + '\n')
            

            print('longest context:{}'.format(max_tokens))
            print('longest target {}'.format(max_tgt))
    
    def train_dataloader(self):
        if self.hparams.sim_train:
            if not self.hparams.adv:
                dataset = IEDataset('preprocessed_simtr_{}/train.jsonl'.format(self.hparams.dataset))
            else:
                dataset = IEDataset('preprocessed_simtr_adv_{}/train.jsonl'.format(self.hparams.dataset))
        else:
            dataset = IEDataset('preprocessed_{}/train.jsonl'.format(self.hparams.dataset))
        
        dataloader = DataLoader(dataset, 
            pin_memory=True, num_workers=2, 
            collate_fn=my_collate,
            batch_size=self.hparams.train_batch_size, 
            shuffle=True)
        return dataloader 

    
    def val_dataloader(self):
        if self.hparams.sim_train:
            if not self.hparams.adv:
                dataset = IEDataset('preprocessed_simtr_{}/val.jsonl'.format(self.hparams.dataset))
            else:
                dataset = IEDataset('preprocessed_simtr_adv_{}/val.jsonl'.format(self.hparams.dataset))
        else:
            dataset = IEDataset('preprocessed_{}/val.jsonl'.format(self.hparams.dataset))
        
        dataloader = DataLoader(dataset, pin_memory=True, num_workers=2, 
            collate_fn=my_collate,
            batch_size=self.hparams.eval_batch_size, shuffle=False)
        return dataloader

    def test_dataloader(self):
        if not self.hparams.adv:
            dataset = IEDataset('preprocessed_simtr_{}/test.jsonl'.format(self.hparams.dataset))
        else:
            dataset = IEDataset('preprocessed_simtr_adv_{}/test.jsonl'.format(self.hparams.dataset))

        dataloader = DataLoader(dataset[:], pin_memory=True, num_workers=2, 
            collate_fn=my_collate, 
            batch_size=self.hparams.eval_batch_size, shuffle=False)

        return dataloader


if __name__ == '__main__':
    parser = argparse.ArgumentParser() 
    parser.add_argument('--train-file',type=str,default='data/kairos/train.jsonl')
    parser.add_argument('--val-file', type=str, default='data/kairos/dev.jsonl')
    parser.add_argument('--test-file', type=str, default='data/kairos/test.jsonl')
    parser.add_argument('--coref-dir', type=str, default='data/kairos/coref')
    parser.add_argument('--use_info', action='store_true', default=True, help='use informative mentions instead of the nearest mention.')
    parser.add_argument('--train_batch_size', type=int, default=2)
    parser.add_argument('--eval_batch_size', type=int, default=4)
    parser.add_argument('--dataset', type=str, default='KAIROS')
    parser.add_argument('--mark-trigger', action='store_true', default=True)
    args = parser.parse_args() 

    dm = KAIROSDataModule(args=args)
    dm.prepare_data() 

    dataloader = dm.train_dataloader() 

    for idx, batch in enumerate(dataloader):
        print(batch)
        break 