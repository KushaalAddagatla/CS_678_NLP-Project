import os 
import argparse 
import torch 
import logging 
import json 


import pytorch_lightning as pl 
from transformers import BartTokenizer, BartConfig
from transformers import AdamW, get_linear_schedule_with_warmup

from .gen import BartConstrainedGen

from collections import defaultdict 
import re

logger = logging.getLogger(__name__)

from sentence_transformers import SentenceTransformer, util
import spacy 
from spacy.tokens import Doc

sim_model = SentenceTransformer('paraphrase-MiniLM-L6-v2')
MAX_LENGTH=512


def load_ontology(dataset, ontology_file=None):
    ontology_dict ={} 
    if not ontology_file: 
        if not dataset:
            raise ValueError
        with open('../event_role_{}.json'.format(dataset),'r') as f:
            ontology_dict = json.load(f)
    else:
        with open(ontology_file,'r') as f:
            ontology_dict = json.load(f)

    for evt_name, evt_dict in ontology_dict.items():
        for i, argname in enumerate(evt_dict['roles']):
            evt_dict['arg{}'.format(i+1)] = argname
            if argname in evt_dict:
                evt_dict[argname].append('arg{}'.format(i+1))
            else:
                evt_dict[argname] = ['arg{}'.format(i+1)]

    for evt_name, evt_dict in ontology_dict.items():
        evt_dict['arg_to_prev'] = {}
        for i, argname in enumerate(evt_dict['roles']):
            template_words = evt_dict['template'].strip().split()
            try:
                idx = template_words.index("<" + evt_dict[argname][0] + ">")
            except ValueError:
                idx = 0
            if idx == 0:
                evt_dict['arg_to_prev'][argname] = "<s>"
            else:
                evt_dict['arg_to_prev'][argname] = template_words[idx-1]

    
    return ontology_dict


class GenIEModel(pl.LightningModule):
    def __init__(self, args):
        super().__init__() 


        self.hparams.update(vars(args))

        self.config=BartConfig.from_pretrained('facebook/bart-large')
        self.tokenizer = BartTokenizer.from_pretrained('facebook/bart-large')
        self.tokenizer.add_tokens([' <arg>',' <tgr>'])

        
        if self.hparams.model=='gen':
            self.model = BartGen(self.config, self.tokenizer)
            self.model.resize_token_embeddings() 
        elif self.hparams.model == 'constrained-gen':
            self.model = BartConstrainedGen(self.config, self.tokenizer)
            self.model.resize_token_embeddings() 
        else:
            raise NotImplementedError



        self.pair_constraints = {
        ('Justice.Sentence.Unspecified_JudgeCourt', 'Life.Die.Unspecified_Victim'),
        ('Justice.Sentence.Unspecified_Defendant', 'Life.Die.Unspecified_Victim'),
        ('Control.ImpedeInterfereWith.Unspecified_Impeder', 'Justice.ArrestJailDetain.Unspecified_Jailer'),
        ('Contact.RequestCommand.Unspecified_Recipient', 'Justice.ArrestJailDetain.Unspecified_Jailer'),
        ('Life.Injure.Unspecified_Injurer', 'Transaction.ExchangeBuySell.Unspecified_Giver'),
        ('Justice.TrialHearing.Unspecified_Defendant', 'Transaction.ExchangeBuySell.Unspecified_Giver'),
        ('Justice.TrialHearing.Unspecified_Defendant', 'Transaction.ExchangeBuySell.Unspecified_Recipient'),
        ('Justice.Sentence.Unspecified_JudgeCourt', 'Life.Die.Unspecified_Victim'), 
        ('Justice.ArrestJailDetain.Unspecified_Detainee', 'Justice.ArrestJailDetain.Unspecified_Detainee'), 
        ('Conflict.Attack.DetonateExplode_Attacker', 'Contact.Contact.Broadcast_Communicator'), 
        ('Conflict.Attack.Unspecified_Attacker', 'Contact.Contact.Broadcast_Communicator'), 
        ('Conflict.Attack.DetonateExplode_Attacker', 'Contact.ThreatenCoerce.Unspecified_Communicator'),
        ('Conflict.Attack.Unspecified_Attacker', 'Contact.ThreatenCoerce.Unspecified_Communicator'),
        }

        self.pair_constrains_adv = {
        ("Conflict.Attack.DetonateExplode_Attacker", "Justice.ArrestJailDetain.Unspecified_Jailer"),
        ("Life.Injure.Unspecified_Victim", "Medical.Intervention.Unspecified_Treater"),
        ("Life.Die.Unspecified_Victim", "Life.Die.Unspecified_Killer"),
        ("Life.Die.Unspecified_Victim", "Life.Injure.Unspecified_Injurer"),
        }
        if self.hparams.adv:
            self.pair_constraints = self.pair_constrains_adv
        self.up_constrains = {
        "Killer_Attacker_Injurer_Damager_Destroyer": "Killer_Attacker_Destroyer_Defendant",
        "JudgeCourt": "JudgeCourt",
        }
        self.up_thresh = 4

        self.ontology_dict = load_ontology(dataset="KAIROS")
        for key in self.ontology_dict:
            for role in self.ontology_dict[key]['arg_to_prev']:
                w = self.ontology_dict[key]['arg_to_prev'][role]
                if w == '<s>':
                    self.ontology_dict[key]['arg_to_prev'][role] = [w, 2] 
                else:
                    w_list = self.tokenizer.tokenize(w, add_prefix_space=True)
                    self.ontology_dict[key]['arg_to_prev'][role] = [w, self.tokenizer.encode_plus(w_list, add_special_tokens=True, add_prefix_space=True)['input_ids'][-2]]

        self.memory = {}
        self.memory_down = {}
        self.memory_up_cnt = defaultdict(int)
        
        with open("../preprocessed_KAIROS/test.jsonl", 'r') as f:
            for line in f:
                ex = json.loads(line.strip())
                doc_key = ex["doc_key"]
                evt_type = ex['event_type']
                if doc_key not in self.memory:
                    self.memory[doc_key] = {}
                    self.memory_down[doc_key] = {}
                    self.memory_up_cnt[doc_key] = {}

                    for evt_type in self.ontology_dict:
                        self.memory[doc_key][evt_type] = {}
                        self.memory_down[doc_key][evt_type]= {}
                        for role in self.ontology_dict[evt_type]['roles']:
                            if role not in self.memory[doc_key][evt_type]:
                                self.memory[doc_key][evt_type][role] = []
                                self.memory_down[doc_key][evt_type][role] = []
                    
                    for role_grp_key, role_grp in self.up_constrains.items():
                        if role_grp not in self.memory_up_cnt[doc_key]:
                            self.memory_up_cnt[doc_key][role_grp] = {}
                            
                            if role_grp_key == 'JudgeCourt':
                                ent = "George O'Toole Jr."
                                w_list = self.tokenizer.tokenize("Jr.", add_prefix_space=True)
                                out_id = self.tokenizer.encode_plus(w_list, add_special_tokens=True, add_prefix_space=True)['input_ids'][1]
                                self.memory_up_cnt[doc_key][role_grp][ent] = [out_id, self.up_thresh]


        self.all_output_templates, self.all_out_template_embs = {}, {}
        for doc_key in self.memory:
            if doc_key not in self.all_output_templates:
                self.all_output_templates[doc_key] = []
                self.all_out_template_embs[doc_key] = []


    def forward(self, inputs):
    
        return self.model(**inputs)


    def training_step(self, batch, batch_idx):

        inputs = {
                    "input_ids": batch["input_token_ids"],
                    "attention_mask": batch["input_attn_mask"],
                    "decoder_input_ids": batch['tgt_token_ids'],
                    "decoder_attention_mask": batch["tgt_attn_mask"],   
                    "task": 0 
                }

        outputs = self.model(**inputs)
        loss = outputs[0]
        loss = torch.mean(loss)

        log = {
            'train/loss': loss, 
        } 
        return {
            'loss': loss, 
            'log': log 
        }
    

    def validation_step(self,batch, batch_idx):
        inputs = {
                    "input_ids": batch["input_token_ids"],
                    "attention_mask": batch["input_attn_mask"],
                    "decoder_input_ids": batch['tgt_token_ids'],
                    "decoder_attention_mask": batch["tgt_attn_mask"],  
                    "task" :0,   
                }
        outputs = self.model(**inputs)
        loss = outputs[0]
        loss = torch.mean(loss)

       
        
        return loss  

    
    def validation_epoch_end(self, outputs):
        avg_loss = torch.mean(torch.stack(outputs))
        log = {
            'val/loss': avg_loss, 
        } 
        return {
            'loss': avg_loss, 
            'log': log 
        }
        
        
        
    def extract_args_from_template(self, evt_type, pred_template,):
        template = self.ontology_dict[evt_type]['template']
        template_words = template.strip().split()
        predicted_words = pred_template.strip().split()
        predicted_args = defaultdict(list)  
        t_ptr= 0
        p_ptr= 0 

        while t_ptr < len(template_words) and p_ptr < len(predicted_words):
            if re.match(r'<(arg\d+)>', template_words[t_ptr]):
                m = re.match(r'<(arg\d+)>', template_words[t_ptr])
                arg_num = m.group(1)
                try:
                    arg_name = self.ontology_dict[evt_type][arg_num]
                except KeyError:
                    print(evt_type)
                    exit() 

                if predicted_words[p_ptr] == '<arg>':

                    p_ptr +=1 
                    t_ptr +=1  
                else:
                    arg_start = p_ptr 
                    while (p_ptr < len(predicted_words)) and ((t_ptr== len(template_words)-1) or (predicted_words[p_ptr] != template_words[t_ptr+1])):
                        p_ptr+=1 
                    arg_text = predicted_words[arg_start:p_ptr]
                    predicted_args[arg_name].append(arg_text)
                    t_ptr+=1 
                
            else:
                t_ptr+=1 
                p_ptr+=1 
        
        return predicted_args

    def test_step(self, batch, batch_idx):

        if self.hparams.knowledge_pair_gen:
            doc_key = batch['doc_key'][-1]
            evt_type = batch['event_type'][-1]
            id_pairs_down = {}
            id_pairs_down_print = {}

            for role, ents in self.memory_down[doc_key][evt_type].items():
                in_id = self.ontology_dict[evt_type]['arg_to_prev'][role][-1]
                if ents:
                    down_out_ids = []
                    down_out_ids_print = []
                    for ent in ents[:]: 
                        down_out_ids.append(ent[-1])
                        down_out_ids_print.append(ent[:-1])

                    id_pairs_down[in_id] = down_out_ids
                    id_pairs_down_print[self.ontology_dict[evt_type]['arg_to_prev'][role][0]]=down_out_ids_print

                    if role == "Participant": 
                        in_id2 = 19
                        id_pairs_down[in_id2] = down_out_ids

            id_pairs_up = {}
            for role in self.ontology_dict[evt_type]['roles']:
                for role_grp_key, role_grp in self.up_constrains.items():
                    if role in role_grp:
                        in_id = self.ontology_dict[evt_type]['arg_to_prev'][role][-1]
                        for ent in self.memory_up_cnt[doc_key][role_grp]:
                            if self.memory_up_cnt[doc_key][role_grp][ent][-1] >= self.up_thresh and self.memory_up_cnt[doc_key][role_grp][ent][0] in batch['input_token_ids']:
                                if in_id not in id_pairs_up: id_pairs_up[in_id] = []
                                id_pairs_up[in_id].append(self.memory_up_cnt[doc_key][role_grp][ent][0])
            
                            

        input_token_ids = batch['input_token_ids']
        if self.hparams.sim_train:
            doc_key = batch['doc_key'][0]
            context_emb = sim_model.encode(batch['context_words'][0], show_progress_bar=False)
            most_sim_out_template = []
            context = batch['context_tokens'][0]
            if len(self.all_out_template_embs[doc_key])>0:
                cosine_scores = util.pytorch_cos_sim([context_emb], self.all_out_template_embs[doc_key])
                most_sim_idx = torch.argmax(cosine_scores, dim=-1)
                most_sim_out_template = self.all_output_templates[doc_key][most_sim_idx]
            context = most_sim_out_template+['</s>']+context

            input_tokens = self.tokenizer.encode_plus(batch['input_template'][0], context,
                    add_special_tokens=True,
                    add_prefix_space=True,
                    max_length=MAX_LENGTH,
                    truncation='only_second',
                    padding='max_length')
            input_token_ids = torch.stack([torch.LongTensor(input_tokens['input_ids'])]) 
            if batch['input_token_ids'].device.type != 'cpu':
                input_token_ids = input_token_ids.cuda()

        sample_output_no_knowledge = self.model.generate({}, {}, input_token_ids, do_sample=False, 
                                max_length=30, num_return_sequences=1,num_beams=1,)

        if self.hparams.knowledge_pair_gen:
            if self.hparams.sample_gen:
                sample_output = self.model.generate(input_token_ids, do_sample=True, 
                                    top_k=20, top_p=0.95, max_length=30, num_return_sequences=1,num_beams=1,
                                )
            else:
                sample_output = self.model.generate(id_pairs_down, id_pairs_up, input_token_ids, do_sample=False, 
                                    max_length=30, num_return_sequences=1,num_beams=1,
                                )


            doc_key = batch['doc_key'][-1]
            evt_type = batch['event_type'][-1]
            pred_template = self.tokenizer.decode(sample_output.squeeze(0), skip_special_tokens=True)
            predicted_args = self.extract_args_from_template(evt_type, pred_template)

            for role in predicted_args:
                for ent in predicted_args[role]:
                    if not ent: continue
                    w_list = self.tokenizer.tokenize(ent[0], add_prefix_space=True)
                    out_id = self.tokenizer.encode_plus(w_list, add_special_tokens=True, add_prefix_space=True)['input_ids'][1]
                    ent.append(out_id)
                    self.memory[doc_key][evt_type][role].append(ent)

                    evt_type_role = "_".join([evt_type, role])
                    for pair in self.pair_constraints:
                        if evt_type_role == pair[0]:
                            evt_type2, role2 = pair[1].split("_")
                            self.memory_down[doc_key][evt_type2][role2].append(ent)

                        if evt_type_role == pair[1]:
                            evt_type2, role2 = pair[0].split("_")
                            self.memory_down[doc_key][evt_type2][role2].append(ent)

                    for role_grp_key, role_grp in self.up_constrains.items():
                        if role in role_grp_key:
                            if ent[0] not in self.memory_up_cnt[doc_key][role_grp]:
                                self.memory_up_cnt[doc_key][role_grp][ent[0]] = [out_id, 1]
                            else:
                                self.memory_up_cnt[doc_key][role_grp][ent[0]][-1] += 1
            
            if id_pairs_down: 
                print(batch_idx+1)
                print(id_pairs_down_print)
                
                print("ored:", self.tokenizer.decode(sample_output_no_knowledge.squeeze(0), skip_special_tokens=True))
                print("pred:", pred_template)
                print("gold:", self.tokenizer.decode(batch['tgt_token_ids'][0], skip_special_tokens=True))

        else:
            sample_output = sample_output_no_knowledge

        sample_output = sample_output.reshape(batch['input_token_ids'].size(0), 1, -1)
        doc_key = batch['doc_key']
        tgt_token_ids = batch['tgt_token_ids']

        if self.hparams.sim_train:
            output_template = self.tokenizer.decode(sample_output[0][0], skip_special_tokens=True)
            out_template_emb = sim_model.encode(output_template, show_progress_bar=False)

            space_tokenized_template = output_template.split()
            tokenized_output_template = [] 
            for w in space_tokenized_template:
                tokenized_output_template.extend(self.tokenizer.tokenize(w, add_prefix_space=True))

            self.all_output_templates[doc_key[0]].append(tokenized_output_template)
            self.all_out_template_embs[doc_key[0]].append(out_template_emb)

        return (doc_key, sample_output, tgt_token_ids) 

    def test_epoch_end(self, outputs):
        with open('checkpoints/{}/predictions.jsonl'.format(self.hparams.ckpt_name),'w') as writer:
            for tup in outputs:
                for idx in range(len(tup[0])):
                    
                    pred = {
                        'doc_key': tup[0][idx],
                        'predicted': self.tokenizer.decode(tup[1][idx].squeeze(0), skip_special_tokens=True),
                        'gold': self.tokenizer.decode(tup[2][idx].squeeze(0), skip_special_tokens=True) 
                    }
                    writer.write(json.dumps(pred)+'\n')

        return {} 


    def configure_optimizers(self):
        self.train_len = len(self.train_dataloader())
        if self.hparams.max_steps > 0:
            t_total = self.hparams.max_steps
            self.hparams.num_train_epochs = self.hparams.max_steps // self.train_len // self.hparams.accumulate_grad_batches + 1
        else:
            t_total = self.train_len // self.hparams.accumulate_grad_batches * self.hparams.num_train_epochs

        logger.info('{} training steps in total.. '.format(t_total)) 
        
        no_decay = ["bias", "LayerNorm.weight"]
        optimizer_grouped_parameters = [
            {
                "params": [p for n, p in self.model.named_parameters() if not any(nd in n for nd in no_decay)],
                "weight_decay": self.hparams.weight_decay,
            },
            {"params": [p for n, p in self.model.named_parameters() if any(nd in n for nd in no_decay)], "weight_decay": 0.0},
        ]
        optimizer = AdamW(optimizer_grouped_parameters, lr=self.hparams.learning_rate, eps=self.hparams.adam_epsilon)
        scheduler =  get_linear_schedule_with_warmup(optimizer, num_warmup_steps=self.hparams.warmup_steps, num_training_steps=t_total)
        scheduler_dict = {
            'scheduler': scheduler,
            'interval': 'step',
            'name': 'linear-schedule',
        }

        return [optimizer, ], [scheduler_dict,]